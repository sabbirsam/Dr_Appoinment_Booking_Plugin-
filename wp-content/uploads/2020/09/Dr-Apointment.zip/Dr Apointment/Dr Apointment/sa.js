jQuery(document).ready(function ($) {
  $("#").click(function () {
    alert("You file is submitted ");
  });

  $("#newsubmitss").click(function () {
    alert("successfull.. ");
  });
});
