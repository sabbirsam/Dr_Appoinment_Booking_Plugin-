jQuery(document).ready(function () {
  // $("#newsubmit").click(function () {
  //   alert("You file is submitted ");

  jQuery("#search").dataTable();
});

//     $("#newsubmit2").click(function () {
//       alert("successfull.. ");
//     });
//   });
